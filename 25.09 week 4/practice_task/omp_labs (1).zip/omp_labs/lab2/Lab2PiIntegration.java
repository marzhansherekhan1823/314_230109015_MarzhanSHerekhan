/* =====================================================================
 * LAB 2 — NUMERICAL INTEGRATION (PI) AND PARALLEL REDUCTIONS
 * Student: Marzhan Sherekhan (230109015)
 *
 * Midpoint Riemann sum for  Integral[0..1] 4/(1+x^2) dx = Pi
 *
 *   Variant A  naive unsynchronised shared accumulator   (data race)
 *   Variant B  synchronized critical section per term    (#pragma omp critical)
 *   Variant C  parallel reduction                        (reduction(+:sum))
 *
 * COMPILE:  javac -d out lab2/Lab2PiIntegration.java
 * RUN:      java -cp out Lab2PiIntegration
 * OUTPUT:   lab2_race.csv, lab2_critical.csv, lab2_scaling.csv
 * ===================================================================== */

import java.io.FileWriter;
import java.io.IOException;
import java.io.PrintWriter;
import java.util.Locale;
import java.util.concurrent.ForkJoinPool;
import java.util.stream.LongStream;

public class Lab2PiIntegration {

    static final long N = 100_000_000L;          // strong-scaling workload
    static final double STEP = 1.0 / N;
    static final long N_CRITICAL = 1_000_000L;   // Task 2.2 uses 1e6 per manual
    static final int[] RACE_P = { 1, 2, 4, 8 };
    static final int[] SCALE_P = { 1, 2, 4, 8, 16 };
    static final int TRIALS = 5;                 // Task 2.3 requires 5 trials

    /* ---------------- Variant A: naive race ---------------- */
    static double runNaiveRace(int threads, long n) throws InterruptedException {
        final double step = 1.0 / n;
        final double[] sharedSum = new double[1];
        Thread[] pool = new Thread[threads];
        long chunk = n / threads;
        for (int t = 0; t < threads; t++) {
            final long start = t * chunk;
            final long end = (t == threads - 1) ? n : start + chunk;
            pool[t] = new Thread(() -> {
                for (long i = start; i < end; i++) {
                    double x = (i + 0.5) * step;
                    sharedSum[0] += 4.0 / (1.0 + x * x);   // UNPROTECTED
                }
            });
            pool[t].start();
        }
        for (Thread t : pool) t.join();
        return sharedSum[0] * step;
    }

    /* ---------------- Variant B: synchronized critical ---------------- */
    static double runCriticalSection(int threads, long n) throws InterruptedException {
        final double step = 1.0 / n;
        final Object lock = new Object();
        final double[] sharedSum = new double[1];
        Thread[] pool = new Thread[threads];
        long chunk = n / threads;
        for (int t = 0; t < threads; t++) {
            final long start = t * chunk;
            final long end = (t == threads - 1) ? n : start + chunk;
            pool[t] = new Thread(() -> {
                for (long i = start; i < end; i++) {
                    double x = (i + 0.5) * step;
                    double term = 4.0 / (1.0 + x * x);
                    synchronized (lock) { sharedSum[0] += term; }   // omp critical
                }
            });
            pool[t].start();
        }
        for (Thread t : pool) t.join();
        return sharedSum[0] * step;
    }

    /* ---------------- Variant C: parallel reduction ---------------- */
    static double runParallelReduction(int threads, long n) throws Exception {
        final double step = 1.0 / n;
        ForkJoinPool pool = new ForkJoinPool(threads);
        try {
            double sum = pool.submit(() ->
                LongStream.range(0, n).parallel().mapToDouble(i -> {
                    double x = (i + 0.5) * step;
                    return 4.0 / (1.0 + x * x);
                }).sum()
            ).get();
            return sum * step;
        } finally {
            pool.shutdown();
        }
    }

    /* ---------------- single-threaded baseline ---------------- */
    static double runSerial(long n) {
        double step = 1.0 / n, sum = 0.0;
        for (long i = 0; i < n; i++) {
            double x = (i + 0.5) * step;
            sum += 4.0 / (1.0 + x * x);
        }
        return sum * step;
    }

    public static void main(String[] args) throws Exception {
        Locale.setDefault(Locale.ROOT);
        int cores = Runtime.getRuntime().availableProcessors();

        System.out.println("=".repeat(80));
        System.out.println(" LAB 2 - NUMERICAL INTEGRATION (PI) AND PARALLEL REDUCTIONS");
        System.out.println("=".repeat(80));
        System.out.printf("Available processors : %d%n", cores);
        System.out.printf("Integration steps N  : %,d%n", N);
        System.out.printf("True Pi              : %.15f%n%n", Math.PI);

        System.out.println("Warming up JIT...");
        runSerial(2_000_000);
        runParallelReduction(4, 2_000_000);
        runCriticalSection(2, 200_000);
        runNaiveRace(2, 200_000);
        System.out.println("Warm-up complete.\n");

        /* ============ TASK 2.1 - RACE CONDITION QUANTIFICATION ============ */
        System.out.println("TASK 2.1 - RACE CONDITION QUANTIFICATION (Variant A)");
        System.out.printf("  N = %,d steps, threads P in {1,2,4,8}%n", N_CRITICAL);
        System.out.println("-".repeat(80));
        System.out.printf("  %-4s | %20s | %14s | %12s%n",
                "P", "Computed Pi", "Abs Error", "Time (ms)");
        System.out.println("  " + "-".repeat(60));

        try (PrintWriter csv = new PrintWriter(new FileWriter("lab2_race.csv"))) {
            csv.println("threads_P,computed_pi,absolute_error,relative_error_pct,time_ms");
            for (int p : RACE_P) {
                long t0 = System.nanoTime();
                double pi = runNaiveRace(p, N_CRITICAL);
                double ms = (System.nanoTime() - t0) / 1e6;
                double err = Math.abs(pi - Math.PI);
                System.out.printf("  %-4d | %20.12f | %14.6e | %12.2f%n", p, pi, err, ms);
                csv.printf("%d,%.12f,%.6e,%.6f,%.4f%n",
                        p, pi, err, 100.0 * err / Math.PI, ms);
            }
        }
        System.out.println("  Saved lab2_race.csv\n");

        /* ============ TASK 2.2 - CRITICAL SECTION OVERHEAD ============ */
        System.out.println("TASK 2.2 - CRITICAL SECTION OVERHEAD (Variant B)");
        System.out.printf("  N = %,d steps%n", N_CRITICAL);
        System.out.println("-".repeat(80));

        long t0 = System.nanoTime();
        double piSerial = runSerial(N_CRITICAL);
        double serialMs = (System.nanoTime() - t0) / 1e6;
        System.out.printf("  Single-threaded baseline : Pi = %.12f | %10.2f ms%n",
                piSerial, serialMs);

        try (PrintWriter csv = new PrintWriter(new FileWriter("lab2_critical.csv"))) {
            csv.println("variant,threads_P,computed_pi,absolute_error,time_ms,"
                      + "overhead_vs_serial_x,contention_overhead_pct");
            csv.printf("serial_baseline,1,%.12f,%.6e,%.4f,1.0000,0.00%n",
                    piSerial, Math.abs(piSerial - Math.PI), serialMs);
            for (int p : RACE_P) {
                t0 = System.nanoTime();
                double pi = runCriticalSection(p, N_CRITICAL);
                double ms = (System.nanoTime() - t0) / 1e6;
                double ratio = ms / serialMs;
                System.out.printf("  synchronized, P = %-2d      : Pi = %.12f | %10.2f ms"
                        + " | %7.2fx slower | contention %7.1f%%%n",
                        p, pi, ms, ratio, 100.0 * (ms - serialMs) / serialMs);
                csv.printf("critical_section,%d,%.12f,%.6e,%.4f,%.4f,%.2f%n",
                        p, pi, Math.abs(pi - Math.PI), ms, ratio,
                        100.0 * (ms - serialMs) / serialMs);
            }
        }
        System.out.println("  Saved lab2_critical.csv\n");

        /* ============ TASK 2.3 / 2.4 - STRONG SCALING ============ */
        System.out.println("TASK 2.3 & 2.4 - STRONG SCALING OF VARIANT C (5 trials each)");
        System.out.printf("  N = %,d steps, P in {1,2,4,8,16}%n", N);
        System.out.println("-".repeat(80));
        System.out.printf("  %-4s | %12s | %20s | %12s | %10s | %10s%n",
                "P", "Mean T(P) ms", "Computed Pi", "Abs Error", "S(P)", "E(P)");
        System.out.println("  " + "-".repeat(76));

        try (PrintWriter csv = new PrintWriter(new FileWriter("lab2_scaling.csv"))) {
            csv.println("threads_P,trial1_ms,trial2_ms,trial3_ms,trial4_ms,trial5_ms,"
                      + "mean_ms,computed_pi,absolute_error,speedup_S,efficiency_E_pct,ideal_linear");
            double baseline = -1;
            for (int p : SCALE_P) {
                double[] trials = new double[TRIALS];
                double pi = 0;
                for (int i = 0; i < TRIALS; i++) {
                    long s = System.nanoTime();
                    pi = runParallelReduction(p, N);
                    trials[i] = (System.nanoTime() - s) / 1e6;
                }
                double mean = 0;
                for (double v : trials) mean += v;
                mean /= TRIALS;
                if (baseline < 0) baseline = mean;
                double S = baseline / mean;
                double E = 100.0 * S / p;
                System.out.printf("  %-4d | %12.2f | %20.12f | %12.3e | %9.3fx | %9.1f%%%n",
                        p, mean, pi, Math.abs(pi - Math.PI), S, E);
                csv.printf("%d,%.4f,%.4f,%.4f,%.4f,%.4f,%.4f,%.12f,%.6e,%.6f,%.4f,%d%n",
                        p, trials[0], trials[1], trials[2], trials[3], trials[4],
                        mean, pi, Math.abs(pi - Math.PI), S, E, p);
            }
        }
        System.out.println("  Saved lab2_scaling.csv");
        System.out.println("\n" + "=".repeat(80));
        System.out.println(" LAB 2 COMPLETE");
        System.out.println("=".repeat(80));
    }
}
