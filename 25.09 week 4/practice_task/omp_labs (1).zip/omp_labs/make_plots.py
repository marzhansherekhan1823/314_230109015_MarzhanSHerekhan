"""
Generates every plot the manual requires, from the CSVs in results/.

  Lab 2  Task 2.4  speedup_efficiency.png   speedup + efficiency vs linear ideal
  Lab 3  Task 3.3  lab3_heatmap.png         P x C execution-time heatmap + bars
  Lab 4  Task 4.1/4.2  lab4_false_sharing.png  three-variant scaling curves
  Lab 5  Task 5.2  lab5_cutoff.png          execution time vs log10(K)
  Lab 6            lab6_pipeline.png        throughput + queue occupancy
  Lab 1  Task 1.2  lab1_oversubscription.png  team lifecycle cost vs P

Usage:  python make_plots.py
"""

import csv, os, sys

try:
    import matplotlib
    matplotlib.use("Agg")
    import matplotlib.pyplot as plt
except ImportError:
    print("matplotlib required:  python -m pip install matplotlib")
    sys.exit(1)

R = "results"
OUT = "results"
INK, GRID = "#1a1a1a", "#d8dbe0"
BLUE, RED, GREY, GREEN, ORANGE = "#1f6feb", "#c0392b", "#7f8c8d", "#1e8e5a", "#b9700a"

plt.rcParams.update({
    "font.size": 10, "axes.edgecolor": "#b9bec6", "axes.labelcolor": INK,
    "text.color": INK, "xtick.color": INK, "ytick.color": INK,
    "axes.spines.top": False, "axes.spines.right": False,
})


def load(name):
    p = os.path.join(R, name)
    if not os.path.exists(p):
        print(f"  skip: {name} not found")
        return None
    with open(p, newline="") as fh:
        return list(csv.DictReader(fh))


made = []

# ---------------------------------------------------------------- LAB 1
rows = load("lab1_oversubscription.csv")
if rows:
    P = [int(r["threads_P"]) for r in rows]
    ms = [float(r["mean_ms"]) for r in rows]
    per = [float(r["us_per_thread"]) for r in rows]
    fig, (a1, a2) = plt.subplots(1, 2, figsize=(11, 4.2))
    a1.plot(P, ms, marker="o", lw=2.2, color=BLUE)
    a1.set_xscale("log", base=2); a1.set_xticks(P); a1.set_xticklabels(map(str, P))
    a1.set_xlabel("Thread team size P"); a1.set_ylabel("Team create + join (ms)")
    a1.set_title("Lab 1 — thread team lifecycle cost", fontsize=11)
    a1.grid(alpha=.3, ls="--", color=GRID)
    a2.bar([str(p) for p in P], per, color=BLUE, width=.6)
    a2.set_xlabel("Thread team size P"); a2.set_ylabel("Microseconds per thread")
    a2.set_title("Lab 1 — amortised cost per thread", fontsize=11)
    a2.grid(alpha=.3, ls="--", axis="y", color=GRID)
    fig.tight_layout(); fig.savefig(f"{OUT}/lab1_oversubscription.png", dpi=200); plt.close(fig)
    made.append("lab1_oversubscription.png")

# ---------------------------------------------------------------- LAB 2
rows = load("lab2_scaling.csv")
if rows:
    P = [int(r["threads_P"]) for r in rows]
    S = [float(r["speedup_S"]) for r in rows]
    E = [float(r["efficiency_E_pct"]) for r in rows]
    fig, ax = plt.subplots(figsize=(9, 5.4))
    ax.plot(P, P, ls="--", lw=1.6, color=GREY, marker="^", ms=6, label="Linear ideal S(P) = P")
    ax.plot(P, S, lw=2.5, color=BLUE, marker="o", ms=7, label="Measured speedup S(P)")
    ax.set_xscale("log", base=2); ax.set_xticks(P); ax.set_xticklabels(map(str, P))
    ax.set_xlabel("Threads P"); ax.set_ylabel("Speedup S(P)", color=BLUE)
    ax.tick_params(axis="y", labelcolor=BLUE)
    ax.grid(alpha=.3, ls="--", color=GRID)
    ax2 = ax.twinx()
    ax2.plot(P, E, lw=2.0, color=RED, marker="s", ms=6, ls="-.", label="Efficiency E(P)")
    ax2.set_ylabel("Parallel efficiency E(P)  [%]", color=RED)
    ax2.tick_params(axis="y", labelcolor=RED); ax2.set_ylim(0, 110)
    ax2.spines["right"].set_visible(True)
    h1, l1 = ax.get_legend_handles_labels(); h2, l2 = ax2.get_legend_handles_labels()
    ax.legend(h1 + h2, l1 + l2, frameon=False, fontsize=9, loc="upper left")
    ax.set_title("Lab 2 Task 2.4 — strong scaling of the parallel reduction", fontsize=11.5)
    fig.tight_layout(); fig.savefig(f"{OUT}/speedup_efficiency.png", dpi=200); plt.close(fig)
    made.append("speedup_efficiency.png")

# ---------------------------------------------------------------- LAB 3
rows = load("lab3_sweep.csv")
if rows:
    Ps = sorted({int(r["threads_P"]) for r in rows})
    Cs = sorted({int(r["chunk_C"]) for r in rows})
    M = [[next(float(r["mean_ms"]) for r in rows
               if int(r["threads_P"]) == p and int(r["chunk_C"]) == c)
          for c in Cs] for p in Ps]

    fig, (a1, a2) = plt.subplots(1, 2, figsize=(12.5, 5))
    im = a1.imshow(M, cmap="RdYlGn_r", aspect="auto")
    a1.set_xticks(range(len(Cs))); a1.set_xticklabels([f"C={c}" for c in Cs])
    a1.set_yticks(range(len(Ps))); a1.set_yticklabels([f"P={p}" for p in Ps])
    for i in range(len(Ps)):
        for j in range(len(Cs)):
            a1.text(j, i, f"{M[i][j]:.0f}", ha="center", va="center", fontsize=9)
    a1.set_title("Lab 3 Task 3.3 — execution time (ms) heatmap", fontsize=11)
    fig.colorbar(im, ax=a1, label="ms")

    w = 0.8 / len(Cs)
    for j, c in enumerate(Cs):
        a2.bar([i + j * w for i in range(len(Ps))], [M[i][j] for i in range(len(Ps))],
               w, label=f"C={c}")
    a2.set_xticks([i + 0.4 - w / 2 for i in range(len(Ps))])
    a2.set_xticklabels([f"P={p}" for p in Ps])
    a2.set_ylabel("Execution time (ms)")
    a2.set_title("Lab 3 — grouped comparison by chunk size", fontsize=11)
    a2.legend(frameon=False, fontsize=9); a2.grid(alpha=.3, ls="--", axis="y", color=GRID)
    fig.tight_layout(); fig.savefig(f"{OUT}/lab3_heatmap.png", dpi=200); plt.close(fig)
    made.append("lab3_heatmap.png")

rows = load("lab3_imbalance.csv")
if rows:
    st = [r for r in rows if r["scheduler"] == "static"]
    gd = [r for r in rows if r["scheduler"] == "guided"]
    if st:
        P = [int(r["threads_P"]) for r in st]
        fig, ax = plt.subplots(figsize=(8.5, 4.6))
        ax.plot(P, [float(r["load_imbalance"]) for r in st], marker="o", lw=2.4,
                color=RED, label="static (contiguous blocks)")
        if gd:
            ax.plot([int(r["threads_P"]) for r in gd],
                    [float(r["load_imbalance"]) for r in gd], marker="s", lw=2.4,
                    color=GREEN, label="guided (decaying chunks)")
        ax.set_xscale("log", base=2); ax.set_xticks(P); ax.set_xticklabels(map(str, P))
        ax.set_xlabel("Threads P")
        ax.set_ylabel("Imbalance  (max − min) / average")
        ax.set_title("Lab 3 Task 3.4 — load imbalance metric", fontsize=11.5)
        ax.grid(alpha=.3, ls="--", color=GRID); ax.legend(frameon=False, fontsize=9)
        fig.tight_layout(); fig.savefig(f"{OUT}/lab3_imbalance.png", dpi=200); plt.close(fig)
        made.append("lab3_imbalance.png")

# ---------------------------------------------------------------- LAB 4
rows = load("lab4_scaling.csv")
if rows:
    P = [int(r["threads_P"]) for r in rows]
    u = [float(r["unpadded_mean_ms"]) for r in rows]
    p_ = [float(r["padded_mean_ms"]) for r in rows]
    t = [float(r["threadlocal_mean_ms"]) for r in rows]
    pen = [float(r["false_sharing_penalty_x"]) for r in rows]

    fig, (a1, a2) = plt.subplots(1, 2, figsize=(12, 4.8))
    a1.plot(P, u, marker="o", lw=2.4, color=RED, label="Unpadded (false sharing)")
    a1.plot(P, p_, marker="s", lw=2.4, color=BLUE, label="Padded (64-byte stride)")
    a1.plot(P, t, marker="^", lw=2.4, color=GREEN, label="Thread-local accumulator")
    a1.set_xscale("log", base=2); a1.set_yscale("log")
    a1.set_xticks(P); a1.set_xticklabels(map(str, P))
    a1.set_xlabel("Threads P"); a1.set_ylabel("Execution time (ms, log scale)")
    a1.set_title("Lab 4 Tasks 4.1–4.3 — scaling of the three layouts", fontsize=11)
    a1.grid(alpha=.3, ls="--", which="both", color=GRID)
    a1.legend(frameon=False, fontsize=9)

    bars = a2.bar([str(x) for x in P], pen,
                  color=[RED if v > 1.5 else (ORANGE if v > 1.1 else GREY) for v in pen], width=.6)
    for b, v in zip(bars, pen):
        a2.text(b.get_x() + b.get_width() / 2, v + max(pen) * .02, f"{v:.2f}x",
                ha="center", fontsize=9)
    a2.axhline(1.0, color=GREY, ls="--", lw=1.3)
    a2.set_xlabel("Threads P"); a2.set_ylabel("Unpadded / Padded")
    a2.set_title("Lab 4 — false sharing penalty ratio", fontsize=11)
    a2.grid(alpha=.3, ls="--", axis="y", color=GRID)
    fig.tight_layout(); fig.savefig(f"{OUT}/lab4_false_sharing.png", dpi=200); plt.close(fig)
    made.append("lab4_false_sharing.png")

# ---------------------------------------------------------------- LAB 5
rows = load("lab5_cutoff.csv")
if rows:
    K = [int(r["cutoff_K"]) for r in rows]
    ms = [float(r["mean_ms"]) for r in rows]
    tasks = [int(r["tasks_created"]) for r in rows]
    best = min(range(len(ms)), key=lambda i: ms[i])

    fig, ax = plt.subplots(figsize=(9.5, 5.2))
    ax.plot(K, ms, marker="o", lw=2.5, color=BLUE, label="Execution time")
    ax.scatter([K[best]], [ms[best]], s=160, facecolors="none", edgecolors=GREEN, lw=2.2,
               zorder=5, label=f"optimum K = {K[best]:,}")
    ax.set_xscale("log"); ax.set_xlabel("Sequential cutoff threshold K (log scale)")
    ax.set_ylabel("Execution time (ms)", color=BLUE)
    ax.tick_params(axis="y", labelcolor=BLUE)
    ax.grid(alpha=.3, ls="--", which="both", color=GRID)
    ax2 = ax.twinx()
    ax2.plot(K, tasks, marker="s", ls="-.", lw=1.8, color=ORANGE, label="Tasks created")
    ax2.set_yscale("log"); ax2.set_ylabel("Tasks created (log scale)", color=ORANGE)
    ax2.tick_params(axis="y", labelcolor=ORANGE); ax2.spines["right"].set_visible(True)
    h1, l1 = ax.get_legend_handles_labels(); h2, l2 = ax2.get_legend_handles_labels()
    ax.legend(h1 + h2, l1 + l2, frameon=False, fontsize=9, loc="upper center")
    ax.set_title("Lab 5 Task 5.2 — cutoff threshold sweep", fontsize=11.5)
    fig.tight_layout(); fig.savefig(f"{OUT}/lab5_cutoff.png", dpi=200); plt.close(fig)
    made.append("lab5_cutoff.png")

# ---------------------------------------------------------------- LAB 6
rows = load("lab6_pipeline.csv")
if rows:
    I = [int(r["filter_intensity"]) for r in rows]
    thr = [float(r["throughput_pkt_per_sec"]) for r in rows]
    q1 = [float(r["avg_queue1_occupancy"]) for r in rows]
    q2 = [float(r["avg_queue2_occupancy"]) for r in rows]

    fig, (a1, a2) = plt.subplots(1, 2, figsize=(12, 4.8))
    a1.plot(I, thr, marker="o", lw=2.5, color=BLUE)
    a1.set_xscale("log", base=2); a1.set_yscale("log")
    a1.set_xticks(I); a1.set_xticklabels(map(str, I))
    a1.set_xlabel("Filter intensity (convolution passes)")
    a1.set_ylabel("Throughput (packets/sec)")
    a1.set_title("Lab 6 — pipeline throughput", fontsize=11)
    a1.grid(alpha=.3, ls="--", which="both", color=GRID)

    w = 0.36
    a2.bar([i - w / 2 for i in range(len(I))], q1, w, color=RED, label="Queue 1 (producer→filter)")
    a2.bar([i + w / 2 for i in range(len(I))], q2, w, color=GREEN, label="Queue 2 (filter→consumer)")
    a2.set_xticks(range(len(I))); a2.set_xticklabels([str(i) for i in I])
    a2.set_xlabel("Filter intensity"); a2.set_ylabel("Mean queue occupancy (capacity 32)")
    a2.set_title("Lab 6 — backpressure locates the bottleneck", fontsize=11)
    a2.legend(frameon=False, fontsize=9); a2.grid(alpha=.3, ls="--", axis="y", color=GRID)
    fig.tight_layout(); fig.savefig(f"{OUT}/lab6_pipeline.png", dpi=200); plt.close(fig)
    made.append("lab6_pipeline.png")

print("\nGenerated:")
for m in made:
    print(f"  results/{m}")
if not made:
    print("  nothing - run the labs first so the CSVs exist")
