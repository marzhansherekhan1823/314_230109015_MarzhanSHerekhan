/* =====================================================================
 * LAB 3 — WORK-SHARING AND LOOP SCHEDULING POLICIES (MANDELBROT)
 * Student: Marzhan Sherekhan (230109015)
 *
 * The Mandelbrot escape-time algorithm is deliberately non-uniform:
 * exterior pixels escape in 2-5 iterations, interior pixels run the full
 * MAX_ITER. Static row partitioning therefore produces severe load
 * imbalance, which dynamic self-scheduling is meant to correct.
 *
 * COMPILE:  javac -d out lab3/Lab3Mandelbrot.java
 * RUN:      java -cp out Lab3Mandelbrot
 * OUTPUT:   lab3_sweep.csv, lab3_imbalance.csv
 *
 * Tasks
 *   3.1 Static and dynamic scheduler construction
 *   3.2 4x4 parameter sweep  P in {2,4,8,16} x C in {1,16,64,256}, 3 runs
 *   3.4 Load imbalance metric (Max - Min) / Average of per-thread work
 * ===================================================================== */

import java.io.FileWriter;
import java.io.IOException;
import java.io.PrintWriter;
import java.util.Locale;
import java.util.concurrent.atomic.AtomicInteger;

public class Lab3Mandelbrot {

    static final int WIDTH = 1920, HEIGHT = 1080, MAX_ITER = 1000;
    static final int[] THREADS = { 2, 4, 8, 16 };
    static final int[] CHUNKS  = { 1, 16, 64, 256 };
    static final int RUNS = 3;

    static final int[][] IMAGE = new int[HEIGHT][WIDTH];

    static int computePixel(int px, int py) {
        double x0 = (px - WIDTH / 2.0) * 4.0 / WIDTH;
        double y0 = (py - HEIGHT / 2.0) * 4.0 / HEIGHT;
        double x = 0.0, y = 0.0;
        int iter = 0;
        while (x * x + y * y <= 4.0 && iter < MAX_ITER) {
            double temp = x * x - y * y + x0;
            y = 2.0 * x * y + y0;
            x = temp;
            iter++;
        }
        return iter;
    }

    /** Result of one render: wall time plus per-thread work counts. */
    static class Render {
        double millis;
        long[] threadWork;    // total escape iterations executed by each thread
        long totalWork;
        double imbalance;     // (max - min) / average
    }

    static double imbalanceOf(long[] work) {
        long max = Long.MIN_VALUE, min = Long.MAX_VALUE, sum = 0;
        for (long w : work) { max = Math.max(max, w); min = Math.min(min, w); sum += w; }
        double avg = (double) sum / work.length;
        return avg == 0 ? 0 : (max - min) / avg;
    }

    /* ---------------- STATIC: contiguous equal row blocks ---------------- */
    static Render runStatic(int numThreads) throws InterruptedException {
        Render r = new Render();
        long[] work = new long[numThreads];
        Thread[] pool = new Thread[numThreads];
        int rowsPer = (HEIGHT + numThreads - 1) / numThreads;

        long t0 = System.nanoTime();
        for (int t = 0; t < numThreads; t++) {
            final int tid = t;
            final int startRow = t * rowsPer;
            final int endRow = Math.min(startRow + rowsPer, HEIGHT);
            pool[t] = new Thread(() -> {
                long local = 0;
                for (int y = startRow; y < endRow; y++)
                    for (int x = 0; x < WIDTH; x++) {
                        int it = computePixel(x, y);
                        IMAGE[y][x] = it;
                        local += it;
                    }
                work[tid] = local;
            });
            pool[t].start();
        }
        for (Thread t : pool) t.join();
        r.millis = (System.nanoTime() - t0) / 1e6;
        r.threadWork = work;
        for (long w : work) r.totalWork += w;
        r.imbalance = imbalanceOf(work);
        return r;
    }

    /* ---------------- DYNAMIC: shared work queue, chunked ---------------- */
    static Render runDynamic(int numThreads, int chunkSize) throws InterruptedException {
        Render r = new Render();
        long[] work = new long[numThreads];
        AtomicInteger workQueue = new AtomicInteger(0);
        Thread[] pool = new Thread[numThreads];

        long t0 = System.nanoTime();
        for (int t = 0; t < numThreads; t++) {
            final int tid = t;
            pool[t] = new Thread(() -> {
                long local = 0;
                int startRow;
                while ((startRow = workQueue.getAndAdd(chunkSize)) < HEIGHT) {
                    int endRow = Math.min(startRow + chunkSize, HEIGHT);
                    for (int y = startRow; y < endRow; y++)
                        for (int x = 0; x < WIDTH; x++) {
                            int it = computePixel(x, y);
                            IMAGE[y][x] = it;
                            local += it;
                        }
                }
                work[tid] = local;
            });
            pool[t].start();
        }
        for (Thread t : pool) t.join();
        r.millis = (System.nanoTime() - t0) / 1e6;
        r.threadWork = work;
        for (long w : work) r.totalWork += w;
        r.imbalance = imbalanceOf(work);
        return r;
    }

    /* ---------------- GUIDED: exponentially decaying chunks ---------------- */
    static Render runGuided(int numThreads) throws InterruptedException {
        Render r = new Render();
        long[] work = new long[numThreads];
        AtomicInteger next = new AtomicInteger(0);
        Thread[] pool = new Thread[numThreads];
        final int P = numThreads;

        long t0 = System.nanoTime();
        for (int t = 0; t < numThreads; t++) {
            final int tid = t;
            pool[t] = new Thread(() -> {
                long local = 0;
                while (true) {
                    int startRow, chunk, cur;
                    do {
                        cur = next.get();
                        if (cur >= HEIGHT) { work[tid] = local; return; }
                        chunk = Math.max(1, (HEIGHT - cur) / (2 * P));
                        startRow = cur;
                    } while (!next.compareAndSet(cur, cur + chunk));
                    int endRow = Math.min(startRow + chunk, HEIGHT);
                    for (int y = startRow; y < endRow; y++)
                        for (int x = 0; x < WIDTH; x++) {
                            int it = computePixel(x, y);
                            IMAGE[y][x] = it;
                            local += it;
                        }
                }
            });
            pool[t].start();
        }
        for (Thread t : pool) t.join();
        r.millis = (System.nanoTime() - t0) / 1e6;
        r.threadWork = work;
        for (long w : work) r.totalWork += w;
        r.imbalance = imbalanceOf(work);
        return r;
    }

    static double meanTimed(double[] r) {
        double s = 0;
        for (int i = 1; i < r.length; i++) s += r[i];
        return s / (r.length - 1);
    }

    public static void main(String[] args) throws Exception {
        Locale.setDefault(Locale.ROOT);
        int cores = Runtime.getRuntime().availableProcessors();

        System.out.println("=".repeat(84));
        System.out.println(" LAB 3 - WORK-SHARING AND LOOP SCHEDULING POLICIES (MANDELBROT)");
        System.out.println("=".repeat(84));
        System.out.printf("Available processors : %d%n", cores);
        System.out.printf("Image                : %d x %d, MAX_ITER = %d%n",
                WIDTH, HEIGHT, MAX_ITER);
        System.out.printf("Sweep                : P in {2,4,8,16} x C in {1,16,64,256}, "
                + "%d runs each%n%n", RUNS);

        System.out.println("Warming up JIT...");
        runStatic(2); runDynamic(2, 16);
        System.out.println("Warm-up complete.\n");

        /* ============ TASK 3.1 — STATIC BASELINE + IMBALANCE ============ */
        System.out.println("TASK 3.1 & 3.4 - STATIC SCHEDULING BASELINE AND LOAD IMBALANCE");
        System.out.println("-".repeat(84));
        System.out.printf("  %-8s | %12s | %16s | %12s | %s%n",
                "Threads", "Mean (ms)", "Total iterations", "Imbalance", "per-thread work");
        System.out.println("  " + "-".repeat(78));

        try (PrintWriter csv = new PrintWriter(new FileWriter("lab3_imbalance.csv"))) {
            csv.println("scheduler,threads_P,chunk,mean_ms,total_iterations,"
                      + "max_thread_work,min_thread_work,avg_thread_work,load_imbalance");
            for (int p : THREADS) {
                double[] times = new double[RUNS];
                Render last = null;
                for (int i = 0; i < RUNS; i++) { last = runStatic(p); times[i] = last.millis; }
                double m = meanTimed(times);
                long max = Long.MIN_VALUE, min = Long.MAX_VALUE;
                for (long w : last.threadWork) { max = Math.max(max, w); min = Math.min(min, w); }
                double avg = (double) last.totalWork / p;
                System.out.printf("  %-8d | %12.2f | %,16d | %12.4f | max=%,d min=%,d%n",
                        p, m, last.totalWork, last.imbalance, max, min);
                csv.printf("static,%d,,%.4f,%d,%d,%d,%.2f,%.6f%n",
                        p, m, last.totalWork, max, min, avg, last.imbalance);
            }

            System.out.println();
            System.out.println("GUIDED SCHEDULING (for comparison)");
            System.out.println("  " + "-".repeat(78));
            for (int p : THREADS) {
                double[] times = new double[RUNS];
                Render last = null;
                for (int i = 0; i < RUNS; i++) { last = runGuided(p); times[i] = last.millis; }
                double m = meanTimed(times);
                long max = Long.MIN_VALUE, min = Long.MAX_VALUE;
                for (long w : last.threadWork) { max = Math.max(max, w); min = Math.min(min, w); }
                double avg = (double) last.totalWork / p;
                System.out.printf("  %-8d | %12.2f | %,16d | %12.4f | max=%,d min=%,d%n",
                        p, m, last.totalWork, last.imbalance, max, min);
                csv.printf("guided,%d,,%.4f,%d,%d,%d,%.2f,%.6f%n",
                        p, m, last.totalWork, max, min, avg, last.imbalance);
            }
        }
        System.out.println("  Saved lab3_imbalance.csv\n");

        /* ============ TASK 3.2 — 4x4 PARAMETER SWEEP ============ */
        System.out.println("TASK 3.2 - 4x4 PARAMETER SWEEP (dynamic scheduling)");
        System.out.println("-".repeat(84));
        System.out.printf("  %-8s |", "P \\ C");
        for (int c : CHUNKS) System.out.printf(" %13s |", "C=" + c);
        System.out.println();
        System.out.println("  " + "-".repeat(78));

        try (PrintWriter csv = new PrintWriter(new FileWriter("lab3_sweep.csv"))) {
            csv.println("scheduler,threads_P,chunk_C,run1_ms,run2_ms,run3_ms,mean_ms,"
                      + "total_iterations,load_imbalance,pixels_per_sec");
            for (int p : THREADS) {
                System.out.printf("  %-8d |", p);
                for (int c : CHUNKS) {
                    double[] times = new double[RUNS];
                    Render last = null;
                    for (int i = 0; i < RUNS; i++) {
                        last = runDynamic(p, c);
                        times[i] = last.millis;
                    }
                    double m = meanTimed(times);
                    System.out.printf(" %10.2f ms |", m);
                    csv.printf("dynamic,%d,%d,%.4f,%.4f,%.4f,%.4f,%d,%.6f,%.2f%n",
                            p, c, times[0], times[1], times[2], m,
                            last.totalWork, last.imbalance,
                            (double) WIDTH * HEIGHT / (m / 1000.0));
                }
                System.out.println();
            }
        }
        System.out.println("\n  Saved lab3_sweep.csv");
        System.out.println("\n" + "=".repeat(84));
        System.out.println(" LAB 3 COMPLETE");
        System.out.println("=".repeat(84));
    }
}
