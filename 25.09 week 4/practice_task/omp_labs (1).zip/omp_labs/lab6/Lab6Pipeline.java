/* =====================================================================
 * LAB 6 (BONUS) — PIPELINE PARALLELISM AND WAVEFRONT PROCESSING
 * Student: Marzhan Sherekhan (230109015)
 *
 * A 3-stage functional pipeline, the OpenMP '#pragma omp sections' /
 * producer-consumer pattern:
 *
 *   Stage 1  PRODUCER  synthesises raw tiles and pushes them downstream
 *   Stage 2  FILTER    applies a 3x3 Gaussian convolution (compute-heavy)
 *   Stage 3  CONSUMER  reduces each tile to min / max / mean / checksum
 *
 * Stages communicate through BOUNDED ArrayBlockingQueues, so a slow stage
 * exerts backpressure on the one feeding it. Queue occupancy is sampled
 * throughout, which is what identifies the bottleneck stage: the queue
 * IN FRONT of the bottleneck fills up, the queue AFTER it stays empty.
 *
 * Shutdown is graceful: each stage forwards a poison pill downstream when
 * its own input is exhausted, so no thread is ever interrupted mid-packet.
 *
 * COMPILE:  javac -d out lab6/Lab6Pipeline.java
 * RUN:      java -cp out Lab6Pipeline
 * OUTPUT:   lab6_pipeline.csv
 * ===================================================================== */

import java.io.FileWriter;
import java.io.IOException;
import java.io.PrintWriter;
import java.util.Locale;
import java.util.concurrent.ArrayBlockingQueue;
import java.util.concurrent.BlockingQueue;
import java.util.concurrent.atomic.AtomicLong;

public class Lab6Pipeline {

    static final int TILE = 64;                 // 64 x 64 tile
    static final int PACKETS = 3000;
    static final int QUEUE_CAPACITY = 32;
    static final int[] FILTER_INTENSITY = { 1, 4, 16, 64 };   // convolution passes

    /** Sentinel marking end-of-stream. */
    static final Packet POISON = new Packet(-1, null);

    static class Packet {
        final int id;
        final double[][] data;
        long tProduced, tFiltered, tConsumed;
        Packet(int id, double[][] data) { this.id = id; this.data = data; }
    }

    static final double[][] GAUSSIAN = {
        { 1 / 16.0, 2 / 16.0, 1 / 16.0 },
        { 2 / 16.0, 4 / 16.0, 2 / 16.0 },
        { 1 / 16.0, 2 / 16.0, 1 / 16.0 }
    };

    static double[][] convolve(double[][] in) {
        int h = in.length, w = in[0].length;
        double[][] out = new double[h][w];
        for (int y = 1; y < h - 1; y++)
            for (int x = 1; x < w - 1; x++) {
                double acc = 0;
                for (int ky = -1; ky <= 1; ky++)
                    for (int kx = -1; kx <= 1; kx++)
                        acc += in[y + ky][x + kx] * GAUSSIAN[ky + 1][kx + 1];
                out[y][x] = acc;
            }
        return out;
    }

    static class Stats {
        double throughputPktPerSec, meanLatencyMs, totalMs;
        double avgQueue1, avgQueue2;
        long checksum;
        String bottleneck;
        double producerBusyMs, filterBusyMs, consumerBusyMs;
    }

    static Stats runPipeline(int intensity) throws InterruptedException {
        BlockingQueue<Packet> q1 = new ArrayBlockingQueue<>(QUEUE_CAPACITY);
        BlockingQueue<Packet> q2 = new ArrayBlockingQueue<>(QUEUE_CAPACITY);

        AtomicLong q1Sum = new AtomicLong(), q2Sum = new AtomicLong(), samples = new AtomicLong();
        AtomicLong checksum = new AtomicLong();
        AtomicLong latencySumNs = new AtomicLong();
        AtomicLong prodBusy = new AtomicLong(), filtBusy = new AtomicLong(), consBusy = new AtomicLong();

        // ---- Stage 1: producer ----
        Thread producer = new Thread(() -> {
            try {
                for (int i = 0; i < PACKETS; i++) {
                    long s = System.nanoTime();
                    double[][] tile = new double[TILE][TILE];
                    for (int y = 0; y < TILE; y++)
                        for (int x = 0; x < TILE; x++)
                            tile[y][x] = ((i * 31L + y * 17L + x * 13L) % 256) / 255.0;
                    Packet p = new Packet(i, tile);
                    p.tProduced = System.nanoTime();
                    prodBusy.addAndGet(System.nanoTime() - s);
                    q1.put(p);                       // blocks when q1 is full
                }
                q1.put(POISON);
            } catch (InterruptedException e) { Thread.currentThread().interrupt(); }
        }, "Stage1-Producer");

        // ---- Stage 2: filter ----
        Thread filter = new Thread(() -> {
            try {
                while (true) {
                    Packet p = q1.take();
                    if (p == POISON) { q2.put(POISON); return; }
                    long s = System.nanoTime();
                    double[][] d = p.data;
                    for (int r = 0; r < intensity; r++) d = convolve(d);
                    Packet out = new Packet(p.id, d);
                    out.tProduced = p.tProduced;
                    out.tFiltered = System.nanoTime();
                    filtBusy.addAndGet(System.nanoTime() - s);
                    q2.put(out);
                }
            } catch (InterruptedException e) { Thread.currentThread().interrupt(); }
        }, "Stage2-Filter");

        // ---- Stage 3: consumer ----
        Thread consumer = new Thread(() -> {
            try {
                while (true) {
                    Packet p = q2.take();
                    if (p == POISON) return;
                    long s = System.nanoTime();
                    double min = Double.MAX_VALUE, max = -Double.MAX_VALUE, sum = 0;
                    for (double[] row : p.data)
                        for (double v : row) {
                            if (v < min) min = v;
                            if (v > max) max = v;
                            sum += v;
                        }
                    double mean = sum / (TILE * TILE);
                    checksum.addAndGet((long) (mean * 1_000_000) + (long) (max * 1000));
                    p.tConsumed = System.nanoTime();
                    latencySumNs.addAndGet(p.tConsumed - p.tProduced);
                    consBusy.addAndGet(System.nanoTime() - s);
                }
            } catch (InterruptedException e) { Thread.currentThread().interrupt(); }
        }, "Stage3-Consumer");

        // ---- queue occupancy sampler ----
        Thread sampler = new Thread(() -> {
            try {
                while (!Thread.currentThread().isInterrupted()) {
                    q1Sum.addAndGet(q1.size());
                    q2Sum.addAndGet(q2.size());
                    samples.incrementAndGet();
                    Thread.sleep(1);
                }
            } catch (InterruptedException e) { /* normal shutdown */ }
        }, "QueueSampler");
        sampler.setDaemon(true);

        long t0 = System.nanoTime();
        producer.start(); filter.start(); consumer.start(); sampler.start();
        producer.join(); filter.join(); consumer.join();
        sampler.interrupt();
        double totalMs = (System.nanoTime() - t0) / 1e6;

        Stats st = new Stats();
        st.totalMs = totalMs;
        st.throughputPktPerSec = PACKETS / (totalMs / 1000.0);
        st.meanLatencyMs = latencySumNs.get() / (double) PACKETS / 1e6;
        long n = Math.max(1, samples.get());
        st.avgQueue1 = q1Sum.get() / (double) n;
        st.avgQueue2 = q2Sum.get() / (double) n;
        st.checksum = checksum.get();
        st.producerBusyMs = prodBusy.get() / 1e6;
        st.filterBusyMs = filtBusy.get() / 1e6;
        st.consumerBusyMs = consBusy.get() / 1e6;

        // The busiest stage is the bottleneck; queue occupancy corroborates it.
        double mx = Math.max(st.producerBusyMs, Math.max(st.filterBusyMs, st.consumerBusyMs));
        st.bottleneck = (mx == st.filterBusyMs) ? "Stage 2 (Filter) - COMPUTE-BOUND"
                      : (mx == st.producerBusyMs) ? "Stage 1 (Producer) - I/O-BOUND"
                      : "Stage 3 (Consumer) - I/O-BOUND";
        return st;
    }

    public static void main(String[] args) throws Exception {
        Locale.setDefault(Locale.ROOT);
        int cores = Runtime.getRuntime().availableProcessors();

        System.out.println("=".repeat(96));
        System.out.println(" LAB 6 (BONUS) - PIPELINE PARALLELISM AND WAVEFRONT PROCESSING");
        System.out.println("=".repeat(96));
        System.out.printf("Available processors : %d%n", cores);
        System.out.printf("Packets              : %,d tiles of %dx%d%n", PACKETS, TILE, TILE);
        System.out.printf("Queue capacity       : %d (bounded, backpressure enabled)%n%n",
                QUEUE_CAPACITY);

        System.out.println("Warming up JIT...");
        runPipeline(1);
        System.out.println("Warm-up complete.\n");

        System.out.println("THROUGHPUT AND BOTTLENECK ANALYSIS ACROSS FILTER WORKLOADS");
        System.out.println("-".repeat(96));
        System.out.printf("  %-10s | %11s | %13s | %11s | %8s | %8s | %s%n",
                "Intensity", "Total (ms)", "Pkts/sec", "Latency ms", "avg Q1", "avg Q2", "Bottleneck");
        System.out.println("  " + "-".repeat(92));

        try (PrintWriter csv = new PrintWriter(new FileWriter("lab6_pipeline.csv"))) {
            csv.println("filter_intensity,total_ms,throughput_pkt_per_sec,mean_latency_ms,"
                      + "avg_queue1_occupancy,avg_queue2_occupancy,producer_busy_ms,"
                      + "filter_busy_ms,consumer_busy_ms,bottleneck_stage,checksum");
            for (int intensity : FILTER_INTENSITY) {
                Stats s = runPipeline(intensity);
                System.out.printf("  %-10d | %11.2f | %13.1f | %11.4f | %8.2f | %8.2f | %s%n",
                        intensity, s.totalMs, s.throughputPktPerSec, s.meanLatencyMs,
                        s.avgQueue1, s.avgQueue2, s.bottleneck);
                csv.printf("%d,%.4f,%.2f,%.6f,%.4f,%.4f,%.4f,%.4f,%.4f,%s,%d%n",
                        intensity, s.totalMs, s.throughputPktPerSec, s.meanLatencyMs,
                        s.avgQueue1, s.avgQueue2, s.producerBusyMs, s.filterBusyMs,
                        s.consumerBusyMs, s.bottleneck.replace(",", ";"), s.checksum);
            }
        }

        System.out.println("\n  Stage busy-time breakdown (identifies the rate limiter):");
        for (int intensity : FILTER_INTENSITY) {
            Stats s = runPipeline(intensity);
            double tot = s.producerBusyMs + s.filterBusyMs + s.consumerBusyMs;
            System.out.printf("    intensity %-3d : producer %5.1f%%  filter %5.1f%%  consumer %5.1f%%%n",
                    intensity, 100 * s.producerBusyMs / tot,
                    100 * s.filterBusyMs / tot, 100 * s.consumerBusyMs / tot);
        }

        System.out.println("\n  Saved lab6_pipeline.csv");
        System.out.println("\n" + "=".repeat(96));
        System.out.println(" LAB 6 COMPLETE");
        System.out.println("=".repeat(96));
    }
}
