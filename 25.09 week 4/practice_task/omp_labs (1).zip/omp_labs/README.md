# High-Performance & Parallel Computing — OpenMP Lab Practice Manual
## Java Edition — Labs 1–5 plus Lab 6 Bonus Challenge

**Student:** Marzhan Sherekhan · **ID:** 230109015
**Course:** Parallel Programming · **Instructor:** Sufyan bin Uzayr

---

## Why Java

The manual offers Python (Numba/Cython) and Java editions. Java was chosen
because `java.lang.Thread` maps onto real OS threads with no global
interpreter lock, so every experiment in the manual actually exhibits the
phenomenon it is designed to demonstrate. Under CPython the GIL serialises
bytecode execution, which would make Lab 1's oversubscription sweep and
Lab 4's false-sharing benchmark produce null results regardless of how the
code is written.

The OpenMP constructs are emulated with their standard JVM counterparts:

| OpenMP directive | Java mechanism used here |
|---|---|
| `#pragma omp parallel` | `ForkJoinPool` + `IntStream.parallel()` |
| `#pragma omp parallel for` | `LongStream.range().parallel()` |
| `reduction(+:var)` | `DoubleStream.sum()` — binary reduction tree |
| `#pragma omp critical` | `synchronized (lock) { ... }` |
| `schedule(static, chunk)` | contiguous index ranges per thread |
| `schedule(dynamic, chunk)` | `AtomicInteger.getAndAdd(chunk)` work queue |
| `schedule(guided)` | CAS loop with exponentially decaying chunk size |
| `#pragma omp task` / `taskwait` | `RecursiveAction` + `invokeAll()` |
| Thread padding / private | 64-byte stride arrays and local scalars |
| `#pragma omp sections` | bounded `ArrayBlockingQueue` pipeline stages |

---

## Requirements

- **JDK 17 or newer** (`javac` must be on PATH — a JRE alone is not enough)
- **Python 3 with matplotlib**, for the plots only: `python -m pip install matplotlib`

---

## Compile and run everything

```powershell
.\run_all.ps1
```

If PowerShell blocks the script:

```powershell
Set-ExecutionPolicy -Scope Process -ExecutionPolicy Bypass
.\run_all.ps1
```

`run_all.bat` does the same job through plain `cmd.exe` if PowerShell
misbehaves. On Linux or macOS, compile and run the labs individually with the
commands below.

Then generate every required figure:

```powershell
python make_plots.py
```

Expect roughly 3–8 minutes for the full suite depending on core count.
**Close browsers and background applications first** — all timings are
wall-clock and background load distorts them.

---

## Compile and run a single lab

```powershell
javac -d out lab1\Lab1ForkJoin.java lab2\Lab2PiIntegration.java lab3\Lab3Mandelbrot.java lab4\Lab4FalseSharing.java lab5\Lab5MergeSort.java lab6\Lab6Pipeline.java

java -cp out Lab1ForkJoin
java -cp out Lab2PiIntegration
java -cp out Lab3Mandelbrot
java -Xmx4g -cp out Lab4FalseSharing
java -Xmx4g -cp out Lab5MergeSort
java -cp out Lab6Pipeline
```

`-Xmx4g` matters for Labs 4 and 5: the merge sort allocates a 5,000,000-element
array plus merge scratch space, and the default heap may be too small.

---

## What each lab measures

### Lab 1 — Fork-Join Model, Team Creation & Thread Scoping
- **1.1** Ten consecutive executions of a 4-thread team, recording completion
  order each time, to demonstrate scheduler non-determinism.
- **1.2** Oversubscription sweep, P ∈ {1, 2, 4, 8, 16, 32, 64}, timing team
  creation and join with an empty body so the measurement isolates lifecycle
  cost from payload.
- **1.3** Core saturation: 10,000,000 square roots per thread, reporting
  aggregate throughput so the hardware ceiling is visible as a plateau.

### Lab 2 — Numerical Integration (π) & Parallel Reductions
Midpoint Riemann sum of ∫₀¹ 4/(1+x²) dx = π, in three variants:
- **Variant A** unsynchronised shared accumulator — a genuine data race
- **Variant B** `synchronized` critical section on every term
- **Variant C** parallel reduction over a `LongStream`

Tasks 2.1–2.4 quantify the race error, the lock contention overhead, strong
scaling over five trials, and speedup/efficiency.

### Lab 3 — Work-Sharing & Loop Scheduling (Mandelbrot)
1920×1080 render at MAX_ITER = 1000, deliberately non-uniform because
exterior pixels escape in 2–5 iterations while interior pixels run the full
1000. Includes the 4×4 sweep of P ∈ {2,4,8,16} × C ∈ {1,16,64,256} and the
load imbalance metric **(max − min) / average** of per-thread iteration counts.

### Lab 4 — Memory Hierarchy, Cache Coherency & False Sharing
Three counter layouts with identical instruction counts:
- **Unpadded** `long[P]` — 8 bytes apart, so 8 counters share one 64-byte line
- **Padded** `long[P*8]` — 64-byte stride, one line each
- **Thread-local** a private scalar, written to the shared array exactly once

### Lab 5 — Recursive Task-Based Parallel Merge Sort
`RecursiveAction` work-stealing merge sort over 5,000,000 integers, with the
cutoff threshold swept over K ∈ {1, 10, 100, 1000, 10000, 50000, 100000} and
a Work-Span analysis. Task creation is counted so the K = 1 pathology is
measurable rather than merely asserted.

### Lab 6 (Bonus) — Pipeline Parallelism
Three-stage pipeline — producer, 3×3 Gaussian convolution filter, statistical
consumer — connected by bounded `ArrayBlockingQueue`s so that a slow stage
applies backpressure upstream. Queue occupancy is sampled throughout: the
queue **in front of** the bottleneck fills while the queue **after** it drains,
which identifies the rate-limiting stage empirically. Shutdown is graceful via
poison-pill sentinels.

---

## Output files

Everything lands in `results/`:

| File | Contents |
|---|---|
| `suite_output.txt` | Full console transcript of all six labs |
| `hw_info.txt` | CPU, cache, memory and JVM specification (Report Section I) |
| `lab1_nondeterminism.txt` | Ten raw runs showing varying completion order |
| `lab1_oversubscription.csv` | Team lifecycle cost vs P |
| `lab1_saturation.csv` | Core saturation throughput |
| `lab2_race.csv` | Race-condition π error vs thread count |
| `lab2_critical.csv` | Critical-section contention overhead |
| `lab2_scaling.csv` | Strong scaling, 5 trials, speedup and efficiency |
| `lab3_sweep.csv` | 4×4 P × C parameter matrix |
| `lab3_imbalance.csv` | Load imbalance for static and guided |
| `lab4_scaling.csv` | Three-variant scaling and false-sharing penalty |
| `lab5_cutoff.csv` | Cutoff sweep with task counts |
| `lab5_workspan.csv` | Work, Span and parallelism metrics |
| `lab6_pipeline.csv` | Throughput, latency, queue occupancy, bottleneck |
| `*.png` | All required figures |

---

## Benchmarking methodology

- **Warm-up.** Every lab performs an untimed warm-up pass before measuring.
  Without it the first measurement runs in the JVM's interpreter rather than
  JIT-compiled, inflating it several-fold and invalidating every comparison
  drawn against it.
- **Repeat runs.** Labs 1, 3, 4 and 5 execute three runs per configuration and
  discard run 1 as cold; Lab 2's scaling task uses five trials as the manual
  specifies.
- **Timing.** `System.nanoTime()` throughout — a monotonic clock. Wall-clock
  time is used deliberately rather than CPU time, since CPU time rises with
  thread count and would make a faster parallel run appear slower.
- **Dead-code defence.** Accumulators are consumed or made `volatile` where a
  JIT could otherwise delete the loop entirely.
- **Neutral locale.** `Locale.ROOT` is set so numeric output uses `.` as the
  decimal separator on any host, keeping the CSVs machine-readable.

---

## Repository layout

```
.
├── README.md
├── run_all.ps1 / run_all.bat      full suite runners
├── make_plots.py                  generates every required figure
├── lab1/Lab1ForkJoin.java
├── lab2/Lab2PiIntegration.java
├── lab3/Lab3Mandelbrot.java
├── lab4/Lab4FalseSharing.java
├── lab5/Lab5MergeSort.java
├── lab6/Lab6Pipeline.java
└── results/                       transcripts, CSV data and figures
```

`out/` holds compiled `.class` files and is regenerated by any build, so it is
excluded from version control.
