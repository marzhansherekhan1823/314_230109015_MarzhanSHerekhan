/* =====================================================================
 * LAB 1 — THE FORK-JOIN MODEL, TEAM CREATION, AND THREAD SCOPING
 * Student: Marzhan Sherekhan (230109015)
 *
 * Emulates  #pragma omp parallel  via ForkJoinPool + parallel streams.
 *
 * COMPILE:  javac -d out lab1/Lab1ForkJoin.java
 * RUN:      java -cp out Lab1ForkJoin
 * OUTPUT:   lab1_nondeterminism.txt, lab1_oversubscription.csv,
 *           lab1_saturation.csv
 *
 * Tasks implemented
 *   1.1 Verification of non-determinism  — 10 consecutive runs, stdout saved
 *   1.2 Thread oversubscription sweep    — P in {1,2,4,8,16,32,64}
 *   1.3 CPU core saturation analysis     — artificial sqrt workload per thread
 * ===================================================================== */

import java.io.FileWriter;
import java.io.IOException;
import java.io.PrintWriter;
import java.util.ArrayList;
import java.util.List;
import java.util.Locale;
import java.util.concurrent.ForkJoinPool;
import java.util.stream.IntStream;

public class Lab1ForkJoin {

    static final int[] SWEEP = { 1, 2, 4, 8, 16, 32, 64 };
    static final int RUNS = 3;                 // run 1 discarded as warm-up
    static final int SATURATION_SQRTS = 10_000_000;   // per manual Task 1.3

    /* ---------- Task 1.1: fork a team and report identities ---------- */
    static List<String> runTeam(int targetThreads) {
        List<String> lines = java.util.Collections.synchronizedList(new ArrayList<>());
        ForkJoinPool pool = new ForkJoinPool(targetThreads);
        try {
            pool.submit(() ->
                IntStream.range(0, targetThreads).parallel().forEach(idx -> {
                    long osTid = Thread.currentThread().getId();
                    String name = Thread.currentThread().getName();
                    boolean isMaster = idx == 0;
                    lines.add(String.format(Locale.ROOT,
                        "[%s] Logical Rank: %d | Worker Thread: %s (OS ID: %d)",
                        isMaster ? "Master" : "Worker", idx, name, osTid));
                })
            ).join();
        } finally {
            pool.shutdown();
        }
        return lines;
    }

    /* ---------- Task 1.2: team create + join cost, no payload ---------- */
    static double teamLifecycleMillis(int p) {
        ForkJoinPool pool = new ForkJoinPool(p);
        long t0 = System.nanoTime();
        try {
            pool.submit(() -> IntStream.range(0, p).parallel()
                    .forEach(i -> { /* empty body: measure fork+join only */ })).join();
        } finally {
            pool.shutdown();
        }
        return (System.nanoTime() - t0) / 1_000_000.0;
    }

    /* ---------- Task 1.3: artificial workload to saturate cores ---------- */
    static double saturationMillis(int p) {
        ForkJoinPool pool = new ForkJoinPool(p);
        long t0 = System.nanoTime();
        try {
            pool.submit(() -> IntStream.range(0, p).parallel().forEach(i -> {
                double acc = 0.0;
                for (int j = 1; j <= SATURATION_SQRTS; j++) acc += Math.sqrt(j);
                if (acc < 0) System.out.print("");   // defeat dead-code elimination
            })).join();
        } finally {
            pool.shutdown();
        }
        return (System.nanoTime() - t0) / 1_000_000.0;
    }

    static double meanTimed(double[] r) {
        double s = 0;
        for (int i = 1; i < r.length; i++) s += r[i];
        return s / (r.length - 1);
    }

    public static void main(String[] args) throws IOException {
        Locale.setDefault(Locale.ROOT);
        int cores = Runtime.getRuntime().availableProcessors();

        System.out.println("=".repeat(76));
        System.out.println(" LAB 1 - FORK-JOIN MODEL, TEAM CREATION AND THREAD SCOPING");
        System.out.println("=".repeat(76));
        System.out.printf("Available processors : %d%n", cores);
        System.out.printf("JVM                  : %s %s%n",
                System.getProperty("java.vm.name"), System.getProperty("java.version"));
        System.out.printf("Common pool parallelism: %d%n%n",
                ForkJoinPool.commonPool().getParallelism());

        /* ================= TASK 1.1 ================= */
        System.out.println("TASK 1.1 - VERIFICATION OF NON-DETERMINISM (10 consecutive runs)");
        System.out.println("-".repeat(76));
        try (PrintWriter pw = new PrintWriter(new FileWriter("lab1_nondeterminism.txt"))) {
            pw.printf("Lab 1 Task 1.1 - 10 consecutive executions, team size 4%n");
            pw.printf("Machine: %d logical processors%n%n", cores);

            List<String> firstOrder = null;
            int identical = 0;
            for (int run = 1; run <= 10; run++) {
                List<String> out = runTeam(4);
                pw.printf("--- RUN %d ---%n", run);
                for (String l : out) pw.println("  " + l);
                pw.println();

                // compare the ORDER of logical ranks as printed
                StringBuilder order = new StringBuilder();
                for (String l : out) {
                    int i = l.indexOf("Rank: ");
                    order.append(l.charAt(i + 6)).append(' ');
                }
                if (firstOrder == null) firstOrder = List.of(order.toString());
                else if (firstOrder.get(0).equals(order.toString())) identical++;

                System.out.printf("  run %2d completion order: %s%n", run, order.toString().trim());
            }
            pw.printf("Runs whose completion order matched run 1: %d of 9%n", identical);
            System.out.printf("%n  Runs matching run 1's order: %d of 9  ->  %s%n%n",
                    identical, identical < 9 ? "NON-DETERMINISTIC (expected)" : "identical this time");
            pw.flush();
        }
        System.out.println("  Saved lab1_nondeterminism.txt\n");

        /* ================= TASK 1.2 ================= */
        System.out.println("TASK 1.2 - THREAD OVERSUBSCRIPTION SWEEP (team lifecycle cost)");
        System.out.println("-".repeat(76));
        System.out.printf("  %-6s | %14s | %14s | %14s%n",
                "P", "run2 (ms)", "run3 (ms)", "mean (ms)");
        System.out.println("  " + "-".repeat(60));

        try (PrintWriter csv = new PrintWriter(new FileWriter("lab1_oversubscription.csv"))) {
            csv.println("threads_P,run1_warmup_ms,run2_ms,run3_ms,mean_ms,us_per_thread");
            for (int p : SWEEP) {
                double[] r = new double[RUNS];
                for (int i = 0; i < RUNS; i++) r[i] = teamLifecycleMillis(p);
                double m = meanTimed(r);
                System.out.printf("  %-6d | %14.4f | %14.4f | %14.4f%n", p, r[1], r[2], m);
                csv.printf("%d,%.6f,%.6f,%.6f,%.6f,%.3f%n",
                        p, r[0], r[1], r[2], m, m * 1000.0 / p);
            }
        }
        System.out.println("  Saved lab1_oversubscription.csv\n");

        /* ================= TASK 1.3 ================= */
        System.out.println("TASK 1.3 - CPU CORE SATURATION ANALYSIS");
        System.out.printf("  Each thread computes %,d square roots.%n", SATURATION_SQRTS);
        System.out.println("  Watch Task Manager > Performance > CPU while this runs.");
        System.out.println("-".repeat(76));
        System.out.printf("  %-6s | %12s | %14s | %14s | %10s%n",
                "P", "mean (ms)", "total sqrt ops", "ops/sec", "vs P=1");
        System.out.println("  " + "-".repeat(68));

        try (PrintWriter csv = new PrintWriter(new FileWriter("lab1_saturation.csv"))) {
            csv.println("threads_P,run1_warmup_ms,run2_ms,run3_ms,mean_ms,total_ops,ops_per_sec,ratio_vs_p1");
            double base = -1;
            for (int p : SWEEP) {
                double[] r = new double[RUNS];
                for (int i = 0; i < RUNS; i++) r[i] = saturationMillis(p);
                double m = meanTimed(r);
                if (base < 0) base = m;
                long totalOps = (long) SATURATION_SQRTS * p;
                double opsPerSec = totalOps / (m / 1000.0);
                System.out.printf("  %-6d | %12.2f | %,14d | %,14.0f | %9.3fx%n",
                        p, m, totalOps, opsPerSec, m / base);
                csv.printf("%d,%.4f,%.4f,%.4f,%.4f,%d,%.2f,%.4f%n",
                        p, r[0], r[1], r[2], m, totalOps, opsPerSec, m / base);
            }
        }
        System.out.println("  Saved lab1_saturation.csv");
        System.out.println("\n" + "=".repeat(76));
        System.out.println(" LAB 1 COMPLETE");
        System.out.println("=".repeat(76));
    }
}
