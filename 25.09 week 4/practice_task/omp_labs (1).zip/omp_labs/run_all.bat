@echo off
REM =====================================================================
REM  OpenMP Lab Practice Manual - full suite runner (cmd.exe fallback)
REM  Usage:  run_all.bat
REM =====================================================================
setlocal

if not exist out     mkdir out
if not exist results mkdir results
set "LOG=results\suite_output.txt"
set "TMPF=%TEMP%\omp_lab_out.txt"

echo.
echo =======================================================================
echo  OpenMP Lab Practice Manual - Java Edition - Full Suite
echo =======================================================================
echo.

where javac >nul 2>&1
if errorlevel 1 (
    echo javac not found on PATH. A JDK is required.
    exit /b 1
)

> "%LOG%" echo =======================================================================
>>"%LOG%" echo  OPENMP LAB PRACTICE MANUAL - JAVA EDITION
>>"%LOG%" echo  Student: Marzhan Sherekhan (230109015)
>>"%LOG%" echo =======================================================================
>>"%LOG%" echo  Timestamp : %DATE% %TIME%
>>"%LOG%" echo  Machine   : %COMPUTERNAME%
>>"%LOG%" echo =======================================================================
>>"%LOG%" echo.

echo Capturing hardware specification...
> results\hw_info.txt echo === Processor ===
wmic cpu get name,NumberOfCores,NumberOfLogicalProcessors,MaxClockSpeed,L2CacheSize,L3CacheSize /format:list >> results\hw_info.txt 2>&1
>>results\hw_info.txt echo.
>>results\hw_info.txt echo === Memory ===
wmic memorychip get capacity,speed,devicelocator /format:list >> results\hw_info.txt 2>&1
>>results\hw_info.txt echo.
>>results\hw_info.txt echo === Java ===
java -version >> results\hw_info.txt 2>&1
echo   Saved results\hw_info.txt
echo.

echo Compiling all six labs...
javac -d out lab1\Lab1ForkJoin.java lab2\Lab2PiIntegration.java lab3\Lab3Mandelbrot.java lab4\Lab4FalseSharing.java lab5\Lab5MergeSort.java lab6\Lab6Pipeline.java
if errorlevel 1 (
    echo COMPILATION FAILED.
    exit /b 1
)
echo   Compiled OK.
echo.

call :runlab Lab1ForkJoin      "LAB 1 - Fork-Join Model ^& Thread Teams"
call :runlab Lab2PiIntegration "LAB 2 - Numerical Integration ^& Reductions"
call :runlab Lab3Mandelbrot    "LAB 3 - Work-Sharing ^& Loop Scheduling"
call :runlab Lab4FalseSharing  "LAB 4 - Cache Coherency ^& False Sharing"
call :runlab Lab5MergeSort     "LAB 5 - Task-Based Parallel Merge Sort"
call :runlab Lab6Pipeline      "LAB 6 - Pipeline Parallelism (BONUS)"

if exist lab*.csv move /Y lab*.csv results\ >nul 2>&1
if exist lab1_nondeterminism.txt move /Y lab1_nondeterminism.txt results\ >nul 2>&1

>>"%LOG%" echo.
>>"%LOG%" echo =======================================================================
>>"%LOG%" echo  SUITE COMPLETE - %DATE% %TIME%
>>"%LOG%" echo =======================================================================

echo.
echo All six labs complete.
echo Transcript : %CD%\%LOG%
echo CSV data   : %CD%\results
echo.
dir /b results
exit /b 0

:runlab
set "CLS=%~1"
set "LABEL=%~2"
echo Running %LABEL% ...
>>"%LOG%" echo.
>>"%LOG%" echo #######################################################################
>>"%LOG%" echo # %LABEL%
>>"%LOG%" echo # command: java -cp out %CLS%
>>"%LOG%" echo # started: %TIME%
>>"%LOG%" echo #######################################################################
>>"%LOG%" echo.
java -Xmx4g -cp out %CLS% > "%TMPF%" 2>&1
type "%TMPF%"
type "%TMPF%" >> "%LOG%"
echo   done.
echo.
exit /b 0
