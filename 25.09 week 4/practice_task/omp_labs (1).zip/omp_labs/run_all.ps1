# =====================================================================
#  OpenMP Lab Practice Manual - full suite runner (Java edition)
#  Student: Marzhan Sherekhan (230109015)
#
#  Usage:  .\run_all.ps1
#  If PowerShell refuses:
#      Set-ExecutionPolicy -Scope Process -ExecutionPolicy Bypass
#
#  run_all.bat is a cmd.exe fallback with identical behaviour.
# =====================================================================

# Deliberately NOT "Stop": java and javac write ordinary progress text to
# stderr, and under Stop PowerShell promotes that to a terminating error.
$ErrorActionPreference = "Continue"

function Invoke-Native {
    param([string]$Exe, [string[]]$Arguments)
    & $Exe @Arguments 2>&1 | ForEach-Object { $_.ToString() }
}

$log = "results\suite_output.txt"
New-Item -ItemType Directory -Force -Path "out"     | Out-Null
New-Item -ItemType Directory -Force -Path "results" | Out-Null

Write-Host ""
Write-Host "=======================================================================" -ForegroundColor Cyan
Write-Host " OpenMP Lab Practice Manual - Java Edition - Full Suite" -ForegroundColor Cyan
Write-Host "=======================================================================" -ForegroundColor Cyan
Write-Host ""

if (-not (Get-Command javac -ErrorAction SilentlyContinue)) {
    Write-Host "javac not found on PATH. A JDK is required (a JRE is not enough)." -ForegroundColor Red
    exit 1
}

# ---- environment banner -------------------------------------------------
$javaVer = "(unknown)"
try {
    $v = Invoke-Native "java" @("-version")
    $real = $v | Where-Object { $_ -notmatch "Picked up (JAVA|_JAVA)" } | Select-Object -First 1
    if ($real) { $javaVer = $real.Trim() }
} catch { }

$cpuName = "(query failed)"; $cpuCores = "(query failed)"; $osName = "(query failed)"
try {
    $cpu = Get-CimInstance Win32_Processor -ErrorAction Stop | Select-Object -First 1
    $cpuName  = $cpu.Name.Trim()
    $cpuCores = "$($cpu.NumberOfCores) physical / $($cpu.NumberOfLogicalProcessors) logical"
} catch { }
try { $osName = (Get-CimInstance Win32_OperatingSystem -ErrorAction Stop).Caption } catch { }

$banner = @(
    "=======================================================================",
    " OPENMP LAB PRACTICE MANUAL - JAVA EDITION",
    " Student: Marzhan Sherekhan (230109015)",
    "=======================================================================",
    " Timestamp : $(Get-Date -Format 'yyyy-MM-dd HH:mm:ss')",
    " Machine   : $env:COMPUTERNAME",
    " OS        : $osName",
    " CPU       : $cpuName",
    " Cores     : $cpuCores",
    " Java      : $javaVer",
    "=======================================================================",
    ""
)
$banner | Tee-Object -FilePath $log

# ---- hardware dump (Section I of the report) ----------------------------
Write-Host "Capturing hardware specification..." -ForegroundColor Yellow
$hw = @()
$hw += "=== Win32_Processor ==="
$hw += (Get-CimInstance Win32_Processor | Select-Object Name, Manufacturer, NumberOfCores,
        NumberOfLogicalProcessors, MaxClockSpeed, L2CacheSize, L3CacheSize |
        Format-List | Out-String).TrimEnd()
$hw += ""
$hw += "=== Win32_CacheMemory ==="
$hw += (Get-CimInstance Win32_CacheMemory | Select-Object Purpose, MaxCacheSize, BlockSize |
        Format-Table -AutoSize | Out-String).TrimEnd()
$hw += ""
$hw += "=== Win32_PhysicalMemory ==="
$hw += (Get-CimInstance Win32_PhysicalMemory | Select-Object Capacity, Speed, DeviceLocator,
        SMBIOSMemoryType | Format-Table -AutoSize | Out-String).TrimEnd()
$hw += ""
$hw += "=== Operating system ==="
$hw += (Get-CimInstance Win32_OperatingSystem | Select-Object Caption, Version, BuildNumber,
        OSArchitecture | Format-List | Out-String).TrimEnd()
$hw += ""
$hw += "=== Java toolchain ==="
$hw += ($v | Out-String).TrimEnd()
$hw | Out-File -FilePath "results\hw_info.txt" -Encoding utf8
Write-Host "  Saved results\hw_info.txt" -ForegroundColor Green
Write-Host ""

# ---- compile ------------------------------------------------------------
Write-Host "Compiling all six labs..." -ForegroundColor Yellow
$src = @("lab1\Lab1ForkJoin.java", "lab2\Lab2PiIntegration.java",
         "lab3\Lab3Mandelbrot.java", "lab4\Lab4FalseSharing.java",
         "lab5\Lab5MergeSort.java", "lab6\Lab6Pipeline.java")
$compile = Invoke-Native "javac" (@("-d", "out") + $src)
$compile | Where-Object { $_ -notmatch "Picked up (JAVA|_JAVA)" } | ForEach-Object { Write-Host $_ }
if ($LASTEXITCODE -ne 0) {
    Write-Host "COMPILATION FAILED." -ForegroundColor Red
    exit 1
}
Write-Host "  Compiled OK." -ForegroundColor Green
Write-Host ""

# ---- run each lab -------------------------------------------------------
$labs = @(
    @{ Class = "Lab1ForkJoin";      Label = "LAB 1 - Fork-Join Model & Thread Teams" },
    @{ Class = "Lab2PiIntegration"; Label = "LAB 2 - Numerical Integration & Reductions" },
    @{ Class = "Lab3Mandelbrot";    Label = "LAB 3 - Work-Sharing & Loop Scheduling" },
    @{ Class = "Lab4FalseSharing";  Label = "LAB 4 - Cache Coherency & False Sharing" },
    @{ Class = "Lab5MergeSort";     Label = "LAB 5 - Task-Based Parallel Merge Sort" },
    @{ Class = "Lab6Pipeline";      Label = "LAB 6 - Pipeline Parallelism (BONUS)" }
)

foreach ($lab in $labs) {
    Write-Host "Running $($lab.Label) ..." -ForegroundColor Yellow
    $hdr = @(
        "",
        "#######################################################################",
        "# $($lab.Label)",
        "# command: java -cp out $($lab.Class)",
        "# started: $(Get-Date -Format 'HH:mm:ss')",
        "#######################################################################",
        ""
    )
    $hdr | Tee-Object -FilePath $log -Append

    Invoke-Native "java" @("-Xmx4g", "-cp", "out", $lab.Class) |
        Where-Object { $_ -notmatch "Picked up (JAVA|_JAVA)" } |
        Tee-Object -FilePath $log -Append

    Write-Host "  done." -ForegroundColor Green
}

# ---- collect the CSVs the labs wrote into results\ ----------------------
Get-ChildItem -Path . -Filter "lab*.csv" -File -ErrorAction SilentlyContinue |
    Move-Item -Destination "results" -Force
Get-ChildItem -Path . -Filter "lab1_nondeterminism.txt" -File -ErrorAction SilentlyContinue |
    Move-Item -Destination "results" -Force

$footer = @(
    "",
    "=======================================================================",
    " SUITE COMPLETE - $(Get-Date -Format 'yyyy-MM-dd HH:mm:ss')",
    "======================================================================="
)
$footer | Tee-Object -FilePath $log -Append

Write-Host ""
Write-Host "All six labs complete." -ForegroundColor Cyan
Write-Host "Transcript : $((Resolve-Path $log).Path)" -ForegroundColor Cyan
Write-Host "CSV data   : $((Resolve-Path 'results').Path)" -ForegroundColor Cyan
Write-Host ""
Get-ChildItem results | Select-Object Name, Length | Format-Table -AutoSize
