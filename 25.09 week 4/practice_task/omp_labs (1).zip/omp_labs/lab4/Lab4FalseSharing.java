/* =====================================================================
 * LAB 4 — MEMORY HIERARCHY, CACHE COHERENCY AND FALSE SHARING
 * Student: Marzhan Sherekhan (230109015)
 *
 * Three counter layouts, identical instruction counts, differing only in
 * where the counters live in memory:
 *
 *   A  UNPADDED       long[P]          adjacent, 8 bytes apart -> one 64 B line
 *   B  PADDED         long[P * 8]      stride 8 longs = 64 bytes -> one line each
 *   C  THREAD-LOCAL   scalar register  written to the shared array ONCE
 *
 * The counters are declared volatile so the JIT cannot hoist them into a
 * register and silently delete the memory traffic the experiment exists to
 * measure. Variant C deliberately keeps a NON-volatile local scalar, which
 * is the point of that variant.
 *
 * COMPILE:  javac -d out lab4/Lab4FalseSharing.java
 * RUN:      java -cp out Lab4FalseSharing
 * OUTPUT:   lab4_scaling.csv
 * ===================================================================== */

import java.io.FileWriter;
import java.io.IOException;
import java.io.PrintWriter;
import java.util.Locale;

public class Lab4FalseSharing {

    static final long ITERATIONS = 100_000_000L;   // per thread, per manual
    static final int[] THREADS = { 1, 2, 4, 8, 16 };
    static final int RUNS = 3;                     // run 1 discarded
    static final int STRIDE = 8;                   // 8 longs * 8 bytes = 64 bytes

    /* A: adjacent volatile counters — all within one or two cache lines */
    static class UnpaddedCounters { public volatile long[] values; }

    /* B: padded — each counter alone on its own 64-byte line */
    static class PaddedCounters { public volatile long[] values; }

    static double runUnpadded(int p) throws InterruptedException {
        UnpaddedCounters c = new UnpaddedCounters();
        c.values = new long[p];
        Thread[] th = new Thread[p];
        long t0 = System.nanoTime();
        for (int t = 0; t < p; t++) {
            final int tid = t;
            th[t] = new Thread(() -> {
                for (long i = 0; i < ITERATIONS; i++) c.values[tid]++;
            });
            th[t].start();
        }
        for (Thread t : th) t.join();
        return (System.nanoTime() - t0) / 1e6;
    }

    static double runPadded(int p) throws InterruptedException {
        PaddedCounters c = new PaddedCounters();
        c.values = new long[p * STRIDE];
        Thread[] th = new Thread[p];
        long t0 = System.nanoTime();
        for (int t = 0; t < p; t++) {
            final int idx = t * STRIDE;
            th[t] = new Thread(() -> {
                for (long i = 0; i < ITERATIONS; i++) c.values[idx]++;
            });
            th[t].start();
        }
        for (Thread t : th) t.join();
        return (System.nanoTime() - t0) / 1e6;
    }

    /* C: thread-local scalar accumulator, one store at the very end */
    static double runThreadLocal(int p) throws InterruptedException {
        final long[] results = new long[p * STRIDE];
        Thread[] th = new Thread[p];
        long t0 = System.nanoTime();
        for (int t = 0; t < p; t++) {
            final int idx = t * STRIDE;
            th[t] = new Thread(() -> {
                long local = 0;                       // CPU register, private
                for (long i = 0; i < ITERATIONS; i++) local++;
                results[idx] = local;                 // ONE write, after the loop
            });
            th[t].start();
        }
        for (Thread t : th) t.join();
        return (System.nanoTime() - t0) / 1e6;
    }

    static double meanTimed(double[] r) {
        double s = 0;
        for (int i = 1; i < r.length; i++) s += r[i];
        return s / (r.length - 1);
    }

    public static void main(String[] args) throws Exception {
        Locale.setDefault(Locale.ROOT);
        int cores = Runtime.getRuntime().availableProcessors();

        System.out.println("=".repeat(88));
        System.out.println(" LAB 4 - MEMORY HIERARCHY, CACHE COHERENCY AND FALSE SHARING");
        System.out.println("=".repeat(88));
        System.out.printf("Available processors : %d%n", cores);
        System.out.printf("Increments per thread: %,d%n", ITERATIONS);
        System.out.printf("Padding stride       : %d longs = %d bytes (one 64-byte line)%n%n",
                STRIDE, STRIDE * 8);

        System.out.println("Warming up JIT...");
        runUnpadded(2); runPadded(2); runThreadLocal(2);
        System.out.println("Warm-up complete.\n");

        System.out.println("TASKS 4.1, 4.2, 4.3 - SCALING PROFILE OF ALL THREE VARIANTS");
        System.out.println("-".repeat(88));
        System.out.printf("  %-4s | %14s | %14s | %16s | %12s | %12s%n",
                "P", "Unpadded (ms)", "Padded (ms)", "ThreadLocal (ms)",
                "FS penalty", "TL speedup");
        System.out.println("  " + "-".repeat(82));

        try (PrintWriter csv = new PrintWriter(new FileWriter("lab4_scaling.csv"))) {
            csv.println("threads_P,unpadded_mean_ms,padded_mean_ms,threadlocal_mean_ms,"
                      + "false_sharing_penalty_x,threadlocal_speedup_x,"
                      + "unpadded_inc_per_sec,padded_inc_per_sec,threadlocal_inc_per_sec,"
                      + "unpadded_r1,unpadded_r2,unpadded_r3,padded_r1,padded_r2,padded_r3,"
                      + "tl_r1,tl_r2,tl_r3");
            for (int p : THREADS) {
                double[] u = new double[RUNS], pd = new double[RUNS], tl = new double[RUNS];
                for (int i = 0; i < RUNS; i++) u[i]  = runUnpadded(p);
                for (int i = 0; i < RUNS; i++) pd[i] = runPadded(p);
                for (int i = 0; i < RUNS; i++) tl[i] = runThreadLocal(p);

                double mu = meanTimed(u), mp = meanTimed(pd), mt = meanTimed(tl);
                double penalty = mu / mp, tlSpeed = mu / mt;
                long total = ITERATIONS * p;

                System.out.printf("  %-4d | %14.2f | %14.2f | %16.2f | %11.3fx | %11.3fx%n",
                        p, mu, mp, mt, penalty, tlSpeed);
                csv.printf("%d,%.4f,%.4f,%.4f,%.6f,%.6f,%.2f,%.2f,%.2f,"
                         + "%.4f,%.4f,%.4f,%.4f,%.4f,%.4f,%.4f,%.4f,%.4f%n",
                        p, mu, mp, mt, penalty, tlSpeed,
                        total / (mu / 1000.0), total / (mp / 1000.0), total / (mt / 1000.0),
                        u[0], u[1], u[2], pd[0], pd[1], pd[2], tl[0], tl[1], tl[2]);
            }
        }
        System.out.println("  Saved lab4_scaling.csv");
        System.out.println("\n  Cache-line arithmetic:");
        System.out.printf("    sizeof(long) = 8 bytes, cache line = 64 bytes"
                + " -> %d counters share one line%n", 64 / 8);
        System.out.printf("    unpadded at P=16 : 16 x 8 = %d bytes -> spans %d cache lines%n",
                16 * 8, (16 * 8 + 63) / 64);
        System.out.printf("    padded   at P=16 : stride %d bytes -> 16 distinct lines%n",
                STRIDE * 8);
        System.out.println("\n" + "=".repeat(88));
        System.out.println(" LAB 4 COMPLETE");
        System.out.println("=".repeat(88));
    }
}
