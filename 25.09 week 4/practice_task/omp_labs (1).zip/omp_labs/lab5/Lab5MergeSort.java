/* =====================================================================
 * LAB 5 — RECURSIVE TASK-BASED PARALLELISM (PARALLEL MERGE SORT)
 * Student: Marzhan Sherekhan (230109015)
 *
 * ForkJoinPool / RecursiveAction is the industry-standard work-stealing
 * scheduler implementing the Cilk / OpenMP task model:
 *     new task           ->  #pragma omp task
 *     invokeAll(a, b)    ->  spawn both, then #pragma omp taskwait
 *
 * Below the sequential cutoff K the recursion switches to Arrays.sort,
 * which is what stops task-creation overhead from swamping the useful work.
 *
 * COMPILE:  javac -d out lab5/Lab5MergeSort.java
 * RUN:      java -cp out Lab5MergeSort
 * OUTPUT:   lab5_cutoff.csv, lab5_workspan.csv
 * ===================================================================== */

import java.io.FileWriter;
import java.io.IOException;
import java.io.PrintWriter;
import java.util.Arrays;
import java.util.Locale;
import java.util.Random;
import java.util.concurrent.ForkJoinPool;
import java.util.concurrent.RecursiveAction;
import java.util.concurrent.atomic.AtomicLong;

public class Lab5MergeSort {

    static final int SIZE = 5_000_000;
    static final int[] CUTOFFS = { 1, 10, 100, 1_000, 10_000, 50_000, 100_000 };
    static final int RUNS = 3;

    static final AtomicLong tasksCreated = new AtomicLong();

    static class MergeSortTask extends RecursiveAction {
        private final int[] array;
        private final int left, right, cutoff;

        MergeSortTask(int[] array, int left, int right, int cutoff) {
            this.array = array; this.left = left; this.right = right; this.cutoff = cutoff;
        }

        @Override
        protected void compute() {
            tasksCreated.incrementAndGet();
            if (right - left <= cutoff) {            // sequential cutoff
                Arrays.sort(array, left, right + 1);
                return;
            }
            int mid = left + (right - left) / 2;
            MergeSortTask l = new MergeSortTask(array, left, mid, cutoff);
            MergeSortTask r = new MergeSortTask(array, mid + 1, right, cutoff);
            invokeAll(l, r);                          // omp task + taskwait
            merge(mid);
        }

        private void merge(int mid) {
            int[] temp = Arrays.copyOfRange(array, left, right + 1);
            int i = 0, j = mid - left + 1, k = left;
            int midOffset = mid - left, endOffset = right - left;
            while (i <= midOffset && j <= endOffset)
                array[k++] = (temp[i] <= temp[j]) ? temp[i++] : temp[j++];
            while (i <= midOffset) array[k++] = temp[i++];
            while (j <= endOffset) array[k++] = temp[j++];
        }
    }

    static boolean isSorted(int[] a) {
        for (int i = 1; i < a.length; i++) if (a[i - 1] > a[i]) return false;
        return true;
    }

    static int[] freshData(long seed) {
        Random rnd = new Random(seed);
        int[] a = new int[SIZE];
        for (int i = 0; i < SIZE; i++) a[i] = rnd.nextInt(10_000_000);
        return a;
    }

    static double meanTimed(double[] r) {
        double s = 0;
        for (int i = 1; i < r.length; i++) s += r[i];
        return s / (r.length - 1);
    }

    public static void main(String[] args) throws Exception {
        Locale.setDefault(Locale.ROOT);
        int cores = Runtime.getRuntime().availableProcessors();

        System.out.println("=".repeat(86));
        System.out.println(" LAB 5 - RECURSIVE TASK-BASED PARALLELISM (PARALLEL MERGE SORT)");
        System.out.println("=".repeat(86));
        System.out.printf("Available processors : %d%n", cores);
        System.out.printf("Array size           : %,d random integers%n", SIZE);
        System.out.printf("Cutoff sweep K       : %s%n%n", Arrays.toString(CUTOFFS));

        /* ---------- Task 5.1: correctness verification ---------- */
        System.out.println("TASK 5.1 - ALGORITHM VERIFICATION");
        System.out.println("-".repeat(86));
        int[] verify = freshData(42);
        ForkJoinPool vpool = new ForkJoinPool();
        tasksCreated.set(0);
        vpool.invoke(new MergeSortTask(verify, 0, verify.length - 1, 10_000));
        vpool.shutdown();
        boolean sorted = isSorted(verify);
        System.out.printf("  Output array sorted ascending : %s%n", sorted ? "PASS" : "FAIL");
        System.out.printf("  first 5  : %s%n", Arrays.toString(Arrays.copyOfRange(verify, 0, 5)));
        System.out.printf("  last 5   : %s%n%n",
                Arrays.toString(Arrays.copyOfRange(verify, SIZE - 5, SIZE)));
        if (!sorted) throw new IllegalStateException("merge sort produced unsorted output");

        /* ---------- Work (T1): sequential baseline ---------- */
        System.out.println("WORK (T_1) - SEQUENTIAL BASELINE");
        System.out.println("-".repeat(86));
        double[] seqRuns = new double[RUNS];
        for (int i = 0; i < RUNS; i++) {
            int[] data = freshData(100 + i);
            long t0 = System.nanoTime();
            Arrays.sort(data);
            seqRuns[i] = (System.nanoTime() - t0) / 1e6;
        }
        double T1 = meanTimed(seqRuns);
        System.out.printf("  Arrays.sort single-threaded T_1 = %.2f ms%n%n", T1);

        /* ---------- Task 5.2: cutoff threshold sweep ---------- */
        System.out.println("TASK 5.2 - CUTOFF THRESHOLD OPTIMISATION SWEEP");
        System.out.println("-".repeat(86));
        System.out.printf("  %-10s | %12s | %14s | %12s | %10s%n",
                "Cutoff K", "Mean (ms)", "Tasks created", "Speedup", "Sorted");
        System.out.println("  " + "-".repeat(72));

        double bestTime = Double.MAX_VALUE;
        int bestK = -1;

        try (PrintWriter csv = new PrintWriter(new FileWriter("lab5_cutoff.csv"))) {
            csv.println("cutoff_K,log10_K,run1_ms,run2_ms,run3_ms,mean_ms,tasks_created,"
                      + "speedup_vs_T1,sorted_ok");
            for (int k : CUTOFFS) {
                double[] runs = new double[RUNS];
                long taskCount = 0;
                boolean ok = true;
                for (int i = 0; i < RUNS; i++) {
                    int[] data = freshData(200 + i);
                    ForkJoinPool pool = new ForkJoinPool();
                    tasksCreated.set(0);
                    long t0 = System.nanoTime();
                    pool.invoke(new MergeSortTask(data, 0, data.length - 1, k));
                    runs[i] = (System.nanoTime() - t0) / 1e6;
                    pool.shutdown();
                    taskCount = tasksCreated.get();
                    if (i == RUNS - 1) ok = isSorted(data);
                }
                double m = meanTimed(runs);
                double sp = T1 / m;
                if (m < bestTime) { bestTime = m; bestK = k; }
                System.out.printf("  %-10d | %12.2f | %,14d | %11.3fx | %10s%n",
                        k, m, taskCount, sp, ok ? "PASS" : "FAIL");
                csv.printf("%d,%.4f,%.4f,%.4f,%.4f,%.4f,%d,%.6f,%s%n",
                        k, Math.log10(k), runs[0], runs[1], runs[2], m, taskCount, sp, ok);
            }
        }
        System.out.printf("%n  Optimal cutoff K = %,d at %.2f ms (%.3fx over sequential)%n",
                bestK, bestTime, T1 / bestTime);
        System.out.println("  Saved lab5_cutoff.csv\n");

        /* ---------- Task 5.3: Work-Span model ---------- */
        System.out.println("TASK 5.3 - WORK-SPAN (CRITICAL PATH) MODEL");
        System.out.println("-".repeat(86));

        // Span approximated by forcing a single worker: the pool cannot overlap
        // any tasks, so the measured time is the serialised critical path.
        double[] spanRuns = new double[RUNS];
        for (int i = 0; i < RUNS; i++) {
            int[] data = freshData(300 + i);
            ForkJoinPool single = new ForkJoinPool(1);
            long t0 = System.nanoTime();
            single.invoke(new MergeSortTask(data, 0, data.length - 1, bestK));
            spanRuns[i] = (System.nanoTime() - t0) / 1e6;
            single.shutdown();
        }
        double Tp1 = meanTimed(spanRuns);

        // Theoretical span of recursive merge sort: the merge phase is
        // sequential O(N) at each of the log2(N/K) levels, so
        //     Span ~ sum over levels of O(N) = O(N log(N/K))  ... but the
        // dominant serial component is the final top-level merge of O(N).
        double levels = Math.log((double) SIZE / bestK) / Math.log(2);
        double Tinf = Tp1 / Math.max(1.0, cores);   // empirical lower bound proxy
        double parallelismTheoretical = Tp1 / bestTime;

        System.out.printf("  Work  T_1  (Arrays.sort, 1 core)          : %10.2f ms%n", T1);
        System.out.printf("  T_1 of the task algorithm (pool size 1)   : %10.2f ms%n", Tp1);
        System.out.printf("  T_P   (best cutoff, full pool)            : %10.2f ms%n", bestTime);
        System.out.printf("  Recursion levels above cutoff log2(N/K)   : %10.2f%n", levels);
        System.out.printf("  Measured parallelism  T_1(task) / T_P     : %10.3f%n",
                parallelismTheoretical);
        System.out.printf("  Available hardware parallelism            : %10d%n", cores);
        System.out.printf("  Parallel efficiency achieved              : %9.1f%%%n",
                100.0 * parallelismTheoretical / cores);

        try (PrintWriter csv = new PrintWriter(new FileWriter("lab5_workspan.csv"))) {
            csv.println("metric,value_ms_or_ratio,note");
            csv.printf("work_T1_arrays_sort,%.4f,single-threaded Arrays.sort baseline%n", T1);
            csv.printf("work_T1_task_algorithm,%.4f,task merge sort on a pool of size 1%n", Tp1);
            csv.printf("T_P_best,%.4f,task merge sort at optimal cutoff K=%d%n", bestTime, bestK);
            csv.printf("optimal_cutoff_K,%d,minimum of the sweep%n", bestK);
            csv.printf("recursion_levels,%.4f,log2(N/K)%n", levels);
            csv.printf("measured_parallelism,%.4f,T_1(task) / T_P%n", parallelismTheoretical);
            csv.printf("hardware_parallelism,%d,availableProcessors%n", cores);
            csv.printf("parallel_efficiency_pct,%.2f,measured / hardware%n",
                    100.0 * parallelismTheoretical / cores);
        }
        System.out.println("  Saved lab5_workspan.csv");
        System.out.println("\n" + "=".repeat(86));
        System.out.println(" LAB 5 COMPLETE");
        System.out.println("=".repeat(86));
    }
}
